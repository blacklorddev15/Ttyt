// ============================================================
//   Group admin checks: phone JIDs, device JIDs, and LIDs
// ============================================================
'use strict';
const { logInfo, logWarn } = require('./logger');

function normNum(jid) {
  if (!jid) return '';
  const s = String(jid).trim();
  const noDomain = s.includes('@') ? s.split('@')[0] : s;
  const noDevice = noDomain.includes(':') ? noDomain.split(':')[0] : noDomain;
  return noDevice.replace(/\D/g, '');
}

function identityValues(value) {
  if (Array.isArray(value)) return value.flatMap(identityValues);
  if (value && typeof value === 'object') {
    return ['id','jid','phoneNumber','phone_number','lid','participant','pn','phoneJid']
      .flatMap((k) => identityValues(value[k]));
  }
  return value == null ? [] : [value];
}

function identityKeys(...values) {
  const keys = new Set();
  for (const value of values.flatMap(identityValues)) {
    const raw = String(value).trim().toLowerCase();
    if (!raw) continue;
    const canonical = raw.replace(/:\d+(?=@)/, '');
    keys.add(canonical);
    const digits = normNum(canonical);
    if (digits) keys.add(digits);
  }
  return keys;
}

function hasIdentity(set, ...values) {
  if (!(set instanceof Set)) return false;
  for (const key of identityKeys(...values)) if (set.has(key)) return true;
  return false;
}

async function getGroupAdminInfo(sock, groupJid, debug = false) {
  try {
    const meta = await sock.groupMetadata(groupJid);
    const admins = new Set();
    const superAdmins = new Set();
    const participants = Array.isArray(meta?.participants) ? meta.participants : [];
    for (const participant of participants) {
      if (participant.admin !== 'admin' && participant.admin !== 'superadmin') continue;
      const keys = identityKeys(participant);
      for (const key of keys) admins.add(key);
      if (participant.admin === 'superadmin') for (const key of keys) superAdmins.add(key);
    }
    const botIds = [sock.user?.id, sock.user?.jid, sock.user?.phoneNumber, sock.user?.lid];
    const botIsAdmin = hasIdentity(admins, ...botIds);
    const botNum = normNum(sock.user?.id || sock.user?.phoneNumber || '');
    if (debug) logInfo('ADMIN DEBUG', `botNum=${botNum} | botIsAdmin=${botIsAdmin ? 'YES' : 'NO'} | adminCount=${participants.filter(p => p.admin).length}`);
    return { admins, superAdmins, botIsAdmin, botNum, meta };
  } catch (e) {
    if (debug) logWarn('ADMIN DEBUG', `getGroupAdminInfo failed: ${e.message}`);
    return { admins: new Set(), superAdmins: new Set(), botIsAdmin: false,
      botNum: normNum(sock.user?.id || ''), meta: null };
  }
}

async function enrichWithAdminStatus(sock, m) {
  m.__senderIsAdmin = false;
  m.__botIsAdmin = false;
  if (!m.key.remoteJid?.endsWith('@g.us')) return;
  const senderIds = [m.key.participant, m.key.participantPn, m.key.participantLid, m.key.senderPn];
  m.__senderNum = normNum(m.key.participantPn || m.key.participant || m.key.participantLid || '');
  const debug = process.env.ADMIN_DEBUG === '1';
  const info = await getGroupAdminInfo(sock, m.key.remoteJid, debug);
  m.__senderIsAdmin = hasIdentity(info.admins, ...senderIds);
  m.__botIsAdmin = info.botIsAdmin;
  if (debug) logInfo('ADMIN DEBUG', `senderAdmin=${m.__senderIsAdmin ? 'YES' : 'NO'} | botAdmin=${m.__botIsAdmin ? 'YES' : 'NO'}`);
}

function getTargetJid(m, args) {
  const rp = m.message?.extendedTextMessage?.contextInfo?.participant;
  if (rp && !rp.endsWith('@g.us')) return rp;
  const mentions = m.message?.extendedTextMessage?.contextInfo?.mentionedJid;
  if (mentions?.length) return mentions[0];
  const n = String(args?.[0] || '').replace(/\D/g, '');
  if (n.length >= 7) return n + '@s.whatsapp.net';
  return null;
}
module.exports = { normNum, identityKeys, hasIdentity, getGroupAdminInfo, enrichWithAdminStatus, getTargetJid };
